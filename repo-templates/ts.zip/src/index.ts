import { tools } from '@nyren/codebase-setup';
 tools.log(tools.success, tools.textGreen('Hello, nyren!'))